# FlowPilot — moduli demo anonimizzati

Questa cartella contiene i moduli estratti dal progetto ricevuto, mantenendo la struttura UI e la logica visuale originale. I riferimenti aziendali, i nomi interni dei workflow, gli URL interni, le email d'esempio e gli ID Google incorporati sono stati rimossi o sostituiti con valori fittizi.

## Moduli

I file HTML vanno creati in Apps Script come file HTML con il nome corrispondente, senza estensione; i file `.gs` vanno creati come file script.

- `Code.gs`, `WorkflowEngine.gs`, `OpsCronDaemon.gs`, `OpsModule_GmailPoller.gs`, `OpsModule_RegexParser.gs`, `OpsModule_Studio.gs`, `OpsWorkflowEngine.gs`
- `Index.html`, `CSS.html`, `JS_Core.html`, `JS_Suitcase.html`, `JS_Alignments.html`, `JS_Schedule.html`, `JS_Settings.html`, `JS_OpsCanvas.html`, `JS_OpsConfig.html`, `JS_Pulse.html`

I nomi degli include HTML in `Index.html` sono stati adeguati ai nomi dei file rinominati.

## Prima esecuzione

1. Crea un nuovo progetto Apps Script e importa i moduli.
2. Esegui manualmente `setupDemoWorkspace()` e autorizza la creazione di un nuovo foglio e di una nuova cartella Drive. La funzione crea risorse dedicate alla demo, vi inserisce soltanto record fittizi e salva i relativi ID nelle Script Properties; non riusa gli ID del file sorgente.
3. Ricarica l'editor o esegui nuovamente una funzione, poi distribuisci la web app solo per test privati.

## Importante prima di registrare o pubblicare

- Il mock non contiene i dati originali e non importa automaticamente fogli, Drive o contenuti del sorgente.
- Le funzioni di automazione Gmail/Drive e i trigger sono rimasti nei moduli per preservare la struttura: non eseguirli nella demo senza prima controllare autorizzazioni e destinatari.
- Non distribuire l'app con accesso pubblico. Il progetto originale contiene funzioni operative e autorizzazioni che non sono state sottoposte a revisione completa di sicurezza.
- Verifica ogni schermata e contenuto prima di registrare e condividere su LinkedIn.
